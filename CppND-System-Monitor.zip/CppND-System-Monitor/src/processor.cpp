#include "processor.h"
#include <chrono>
#include <thread>
#include <ctime>
#include <iostream>

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() { 
  float nonIdleTime;
  float idleTime;
  float utilization;

  std::string line;
  std::ifstream stream;       
  stream.open(LinuxParser::kProcDirectory + LinuxParser::kStatFilename);
  std::getline(stream, line);
  std::istringstream linestream(line);
  linestream >> cpu >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal >> guest >> guestnice;
  if(cpu == "cpu"){
    nonIdleTime = std::stof(user)-std::stof(guest)+std::stof(nice)-std::stof(guestnice)+std::stof(system)+std::stof(irq)+std::stof(softirq)+std::stof(steal);
    idleTime = std::stof(idle) + std::stof(iowait);
  }
  stream.close();
  utilization = (nonIdleTime)/(nonIdleTime+idleTime);
  return utilization; 
}