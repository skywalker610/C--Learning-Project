#include <string>

#include "format.h"

using std::string;

// TODO: Complete this helper function
// INPUT: Long int measuring seconds
// OUTPUT: HH:MM:SS
// REMOVE: [[maybe_unused]] once you define the function
string Format::ElapsedTime(long seconds) { 
    string uptime;
    long hour,min,sec;
    string hourstr,minstr,secstr;
    hour = seconds/3600;
    min = (seconds - 3600*hour)/60;
    sec = seconds - 3600*hour - min*60;
    if (hour < 10)
    hourstr = "0"+std::to_string(hour);
    else
    hourstr = std::to_string(hour);
    if (min < 10)
    minstr = "0"+std::to_string(min);
    else
    minstr = std::to_string(min);
    if (sec < 10)
    secstr = "0"+std::to_string(sec);
    else
    secstr = std::to_string(sec);
    uptime = hourstr+":"+minstr+":"+secstr;
    return uptime; 
}